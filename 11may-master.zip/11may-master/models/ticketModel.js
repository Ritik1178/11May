const fs = require('fs').promises;
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const dbPath = path.join(__dirname, '../db.json');

const readDb = async () => {
  try {
    const data = await fs.readFile(dbPath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return { tickets: [] };
  }
};

const writeDb = async (data) => {
  await fs.writeFile(dbPath, JSON.stringify(data, null, 2));
};

const getAllTickets = async () => {
  const db = await readDb();
  return db.tickets;
};

const getTicketById = async (id) => {
  const db = await readDb();
  return db.tickets.find(ticket => ticket.id === id);
};

const createTicket = async (ticketData) => {
  const db = await readDb();
  const newTicket = {
    id: uuidv4(),
    ...ticketData,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.tickets.push(newTicket);
  await writeDb(db);
  return newTicket;
};

const updateTicket = async (id, updateData) => {
  const db = await readDb();
  const ticketIndex = db.tickets.findIndex(ticket => ticket.id === id);
  
  if (ticketIndex === -1) return null;
  
  db.tickets[ticketIndex] = {
    ...db.tickets[ticketIndex],
    ...updateData
  };
  
  await writeDb(db);
  return db.tickets[ticketIndex];
};

const deleteTicket = async (id) => {
  const db = await readDb();
  const ticketIndex = db.tickets.findIndex(ticket => ticket.id === id);
  
  if (ticketIndex === -1) return false;
  
  db.tickets.splice(ticketIndex, 1);
  await writeDb(db);
  return true;
};

const resolveTicket = async (id) => {
  const db = await readDb();
  const ticketIndex = db.tickets.findIndex(ticket => ticket.id === id);
  
  if (ticketIndex === -1) return null;
  
  db.tickets[ticketIndex].status = 'resolved';
  await writeDb(db);
  return db.tickets[ticketIndex];
};

module.exports = {
  getAllTickets,
  getTicketById,
  createTicket,
  updateTicket,
  deleteTicket,
  resolveTicket
}; 