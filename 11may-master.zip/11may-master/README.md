# Ticketing System

A simple ticketing system built with Express.js that allows users to create, update, view, and delete support tickets.

## Features

- Create tickets with title, description, priority, and user
- View all tickets or a specific ticket by ID
- Update ticket details
- Delete tickets
- Resolve tickets (change status from pending to resolved)
- Data validation middleware
- Default "pending" status for new tickets

## Setup

1. Install dependencies:
```bash
npm install
```

2. Start the server:
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

## API Endpoints

- GET /tickets - Get all tickets
- GET /tickets/:id - Get a specific ticket
- POST /tickets - Create a new ticket
- PUT /tickets/:id - Update a ticket
- DELETE /tickets/:id - Delete a ticket
- PATCH /tickets/:id/resolve - Resolve a ticket

## Example Request

Create a new ticket:
```bash
curl -X POST http://localhost:3000/tickets \
-H "Content-Type: application/json" \
-d '{
  "title": "Login Issue",
  "description": "Unable to login",
  "priority": "high",
  "user": "John Doe"
}'
``` 