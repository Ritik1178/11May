const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.json());

const dishesFilePath = path.join(__dirname, 'db.json');

const readDishes = () => {
  const data = fs.readFileSync(dishesFilePath);
  return JSON.parse(data).dishes;
};

const writeDishes = (dishes) => {
  const data = JSON.stringify({ dishes }, null, 2);
  fs.writeFileSync(dishesFilePath, data);
};

app.post('/dishes', (req, res) => {
  const dishes = readDishes();
  const newDish = req.body;
  newDish.id = dishes.length ? dishes[dishes.length - 1].id + 1 : 1;
  dishes.push(newDish);
  writeDishes(dishes);
  res.status(201).json(newDish);
});

app.get('/dishes', (req, res) => {
  const dishes = readDishes();
  res.json(dishes);
});

app.get('/dishes/:id', (req, res) => {
  const dishes = readDishes();
  const dish = dishes.find(d => d.id === parseInt(req.params.id));
  if (dish) {
    res.json(dish);
  } else {
    res.status(404).json({ error: 'Dish not found' });
  }
});

app.put('/dishes/:id', (req, res) => {
  const dishes = readDishes();
  const index = dishes.findIndex(d => d.id === parseInt(req.params.id));
  if (index !== -1) {
    dishes[index] = { ...dishes[index], ...req.body };
    writeDishes(dishes);
    res.json(dishes[index]);
  } else {
    res.status(404).json({ error: 'Dish not found' });
  }
});

app.delete('/dishes/:id', (req, res) => {
  const dishes = readDishes();
  const index = dishes.findIndex(d => d.id === parseInt(req.params.id));
  if (index !== -1) {
    dishes.splice(index, 1);
    writeDishes(dishes);
    res.status(204).send();
  } else {
    res.status(404).json({ error: 'Dish not found' });
  }
});

app.get('/dishes/get', (req, res) => {
  const dishes = readDishes();
  const name = req.query.name;
  const filteredDishes = dishes.filter(dish => dish.name.toLowerCase().includes(name.toLowerCase()));
  if (filteredDishes.length) {
    res.json(filteredDishes);
  } else {
    res.status(404).json({ message: 'No dishes found' });
  }
});

app.use((req, res) => {
  res.status(401).json({ error: '401 Not Found' });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
