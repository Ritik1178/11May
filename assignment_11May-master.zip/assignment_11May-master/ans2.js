const express = require('express');
const app = express();
const port = 3332;

app.use(express.json());

const users = [
  { id: 1, name: 'John Dow', email: 'john@wsample.com' },
  { id: 2, name: 'Bob Smith', email: 'bob@wexample.co' },
  { id: 3, name: 'Alice White', email: 'alice@sample.co' }
];

app.get('/users/get', (req, res) => {
  const user = { id: 1, name: 'John Dow', email: 'john@wsample.com' };
  res.json(user);
});

app.get('/users/list', (req, res) => {
  res.json(users);
});

app.use((req, res) => {
  res.status(401).json({ error: '401 Not Found' });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/users/list`);
});
