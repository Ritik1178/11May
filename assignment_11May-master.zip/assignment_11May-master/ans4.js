const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.json());

const booksFilePath = path.join(__dirname, 'db.json');

const readBooks = () => {
  const data = fs.readFileSync(booksFilePath);
  return JSON.parse(data).books;
};

const writeBooks = (books) => {
  const data = JSON.stringify({ books }, null, 2);
  fs.writeFileSync(booksFilePath, data);
};

app.post('/books', (req, res) => {
  const books = readBooks();
  const newBook = req.body;
  newBook.id = books.length ? books[books.length - 1].id + 1 : 1;
  books.push(newBook);
  writeBooks(books);
  res.status(201).json(newBook);
});

app.get('/books', (req, res) => {
  const books = readBooks();
  res.json(books);
});

app.get('/books/:id', (req, res) => {
  const books = readBooks();
  const book = books.find(b => b.id === parseInt(req.params.id));
  if (book) {
    res.json(book);
  } else {
    res.status(404).json({ error: 'Book not found' });
  }
});

app.put('/books/:id', (req, res) => {
  const books = readBooks();
  const index = books.findIndex(b => b.id === parseInt(req.params.id));
  if (index !== -1) {
    books[index] = { ...books[index], ...req.body };
    writeBooks(books);
    res.json(books[index]);
  } else {
    res.status(404).json({ error: 'Book not found' });
  }
});

app.delete('/books/:id', (req, res) => {
  const books = readBooks();
  const index = books.findIndex(b => b.id === parseInt(req.params.id));
  if (index !== -1) {
    books.splice(index, 1);
    writeBooks(books);
    res.status(204).send();
  } else {
    res.status(404).json({ error: 'Book not found' });
  }
});

app.get('/books/search', (req, res) => {
  const books = readBooks();
  const { author, title } = req.query;
  let filteredBooks = books;
  
  if (author) {
    filteredBooks = filteredBooks.filter(book => book.author.toLowerCase().includes(author.toLowerCase()));
  }
  
  if (title) {
    filteredBooks = filteredBooks.filter(book => book.title.toLowerCase().includes(title.toLowerCase()));
  }
  
  if (filteredBooks.length) {
    res.json(filteredBooks);
  } else {
    res.status(404).json({ message: 'No books found' });
  }
});

app.use((req, res) => {
  res.status(400).json({ error: '400 Not Found' });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
