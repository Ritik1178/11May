const express = require('express');
const app = express();
const PORT = 3000;

app.get('/home', (req, res) => {
    res.send('Welcome to Home Page');
});

app.get('/aboutus', (req, res) => {
    res.json({ message: 'Welcome to About Us' });
});

app.get('/contactus', (req, res) => {
    res.json({
        phone: '1234567890',
        email: 'abc@company.com',
        address: 'India'
    });
});

app.use((req, res) => {
    res.status(404).send('404 Not Found');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}/contactus`);
});
